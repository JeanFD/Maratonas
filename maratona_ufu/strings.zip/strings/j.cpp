//Passou durante o contest

#include <bits/stdc++.h>

using namespace std;

#define _ ios_base::sync_with_stdio(0); cin.tie(0);
#define endl '\n'

int main(){_
    string ent1, ent2;
    getline(cin, ent1);
    getline(cin, ent2);
    cout<<(ent1==ent2)<<endl;
    return 0;
}